
<footer class="footer" style="background-color:beige;">

<!-- Designing footer in grid format -->
   <section class="grid">

      <div class="box">
         <h3>quick links</h3>
         <a href="home.php"> <i class="fa fa-arrow-right"></i>Home</a>
         <a href="about.php"> <i class="fa fa-arrow-right"></i>About</a>
         <a href="shop.php"> <i class="fa fa-arrow-right"></i>Shop</a>
         <a href="contact.php"> <i class="fa fa-arrow-right"></i>Contact</a>
      </div>

      <div class="box">
         <h3>extra links</h3>
         <a href="user_login.php"> <i class="fa fa-arrow-right"></i>Login</a>
         <a href="user_register.php"> <i class="fa fa-arrow-right"></i>Register</a>
         <a href="cart.php"> <i class="fa fa-arrow-right"></i>Cart</a>
         <a href="orders.php"> <i class="fa fa-arrow-right"></i>Orders</a>
      </div>

      <div class="box">
         <h3>Contact Us</h3>
         <a href="tel:1234567890"><i class="fa fa-phone-square"></i> +647 998 8889</a>
         <a href="tel:11122233333"><i class="fa fa-phone-square"></i> +437 889 9998</a>
         <a href="mailto:ayush3366ch@gmail.com"><i class="fas fa-envelope"></i>OpenCart@gmail.com</a>
         <a href="https://www.google.com/myplace"><i class="fa fa-globe"></i>Mississauga,Ontario,Canada </a>
      </div>

      <div class="box">
         <h3>follow us</h3>
         <a href="#"><i class="fab fa-instagram"></i>instagram</a>
         <a href="#"><i class="fab fa-telegram"></i>telegram</a>
         <a href="#"><i class="fab fa-facebook-f"></i>facebook</a>
         <a href="#"><i class="fab fa-snapchat"></i>snapchat</a>
      </div>

   </section>

   <div class="credit" style="background-color:mediumseagreen;color:white;">&copy; Copyright @ <?= date('Y'); ?> by <span style="color:yellow">OpenCart</span> | all rights reserved!</div>

</footer>
