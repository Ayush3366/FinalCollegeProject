<?php
   if(isset($message)){
      foreach($message as $message){
         echo '
         <div class="message">
            <span>'.$message.'</span>
            <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
         </div>
         ';
      }
   }
?>

<header class="header" style="background-color:mediumseagreen;">

   <section class="flex">

      <a href="home.php" class="logo" style="color:white">OpenCart<span>.</span></a>

      <nav class="navbar">
         <a href="home.php" style="color:white">Home</a>
         <a href="about.php" style="color:white">About</a>
         <a href="orders.php" style="color:white">Orders</a>
         <a href="shop.php" style="color:white">Shop</a>
         <a href="contact.php" style="color:white">Contact</a>
      </nav>

      <div class="icons" >
         <?php
            $count_wishlist_items = $conn->prepare("SELECT * FROM `wishlist` WHERE user_id = ?");
            $count_wishlist_items->execute([$user_id]);
            $total_wishlist_counts = $count_wishlist_items->rowCount();

            $count_cart_items = $conn->prepare("SELECT * FROM `cart` WHERE user_id = ?");
            $count_cart_items->execute([$user_id]);
            $total_cart_counts = $count_cart_items->rowCount();
         ?>
         <div id="menu-btn" class="fas fa-bars" ></div>
         <a href="search_page.php" style="color:white"><i class="fas fa-search-plus"></i></a>
         <a href="wishlist.php" style="color:white"><i class="fas fa-thumbs-up"></i><span>(<?= $total_wishlist_counts; ?>)</span></a>
         <a href="cart.php" style="color:white"><i class="fas fa-cart-plus"></i><span>(<?= $total_cart_counts; ?>)</span></a>
         <div id="user-btn" class="fas fa-user-circle" ></div>
      </div>

      <div class="profile">
         <?php
            $select_profile = $conn->prepare("SELECT * FROM `users` WHERE id = ?");
            $select_profile->execute([$user_id]);
            if($select_profile->rowCount() > 0){
            $fetch_profile = $select_profile->fetch(PDO::FETCH_ASSOC);
         ?>
         <p><?= $fetch_profile["name"]; ?></p>
         <a href="update_user.php" class="btn">update profile</a>
         <div class="flex-btn">
            <a href="user_register.php" class="option-btn">register</a>
            <a href="user_login.php" class="option-btn">login</a>
         </div>
         <a href="components/user_logout.php" class="delete-btn" onclick="return confirm('logout from the website?');">logout</a>
         <?php
            }else{
         ?>
         <p>Please Login or Register</p>
         <div class="flex-btn">
            <a href="user_register.php" class="option-btn">register</a>
            <a href="user_login.php" class="option-btn">login</a>
         </div>
         <?php
            }
         ?>


      </div>

   </section>

</header>
