<?php

// Connecting to database
include 'components/connect.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
};

?>

<!-- Html starts here -->
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>about</title>

   <link rel="stylesheet" href="https://unpkg.com/swiper@8/swiper-bundle.min.css" />

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- linking css file  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>

<!-- including header file -->
<?php include 'components/user_header.php'; ?>

<section class="about">

   <div class="row">

      <!-- <div class="image">
         <img src="images/about-img.svg" alt="">
      </div> -->

      <div class="content">
         <h3>About Us</h3>
         <p>Our Ecommerce company is based on Mississauga,Ontario,Canada . We are known for delivering quality products in quick time . Our company has been over a decade and have a lot happy customers .  </p>
         <a href="contact.php" class="option-btn">contact us</a>
      </div>

   </div>

</section>

<section class="reviews">

   <h1 class="heading" style="background-color:lightblue">Customer reviews</h1>

   <div class="swiper reviews-slider">

   <div class="swiper-wrapper">

      <div class="swiper-slide slide">
         <img src="images/person1.png" alt="">
         <p>Best Ecommerce platform out there.</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Joe</h3>
      </div>

      <div class="swiper-slide slide">
         <img src="images/person2.png" alt="">
         <p>Loved It! </p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
         </div>
         <h3>Ashley</h3>
      </div>

      <div class="swiper-slide slide">
         <img src="images/person3.png" alt="">
         <p>I love to shop here . Best platform . Go for it </p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Michelle</h3>
      </div>





   </div>

   <div class="swiper-pagination"></div>

   </div>

</section>









<?php include 'components/footer.php'; ?>

<script src="https://unpkg.com/swiper@8/swiper-bundle.min.js"></script>

<script src="js/script.js"></script>

<script>

var swiper = new Swiper(".reviews-slider", {
   loop:true,
   spaceBetween: 20,
   pagination: {
      el: ".swiper-pagination",
      clickable:true,
   },
   breakpoints: {
      0: {
        slidesPerView:1,
      },
      768: {
        slidesPerView: 2,
      },
      991: {
        slidesPerView: 3,
      },
   },
});

</script>

</body>
</html>
