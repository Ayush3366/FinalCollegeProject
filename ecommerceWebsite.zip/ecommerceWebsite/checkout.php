<?php
// Connecting to database
include 'components/connect.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
   header('location:user_login.php');
};


if(isset($_POST['order'])){

   $name = $_POST['name'];
   $name = filter_var($name, FILTER_SANITIZE_STRING);
   $number = $_POST['number'];
   $number = filter_var($number, FILTER_SANITIZE_STRING);
   $email = $_POST['email'];
   $email = filter_var($email, FILTER_SANITIZE_STRING);
   $method = $_POST['method'];
   $method = filter_var($method, FILTER_SANITIZE_STRING);
   $address = 'flat no. '. $_POST['flat'] .', '. $_POST['street'] .', '. $_POST['city'] .', '. $_POST['state'] .', '. $_POST['country'] .' - '. $_POST['pin_code'];
   $address = filter_var($address, FILTER_SANITIZE_STRING);
   $total_products = $_POST['total_products'];
   $total_price = $_POST['total_price'];

   $check_cart = $conn->prepare("SELECT * FROM `cart` WHERE user_id = ?");
   $check_cart->execute([$user_id]);

   if($check_cart->rowCount() > 0){

      $insert_order = $conn->prepare("INSERT INTO `orders`(user_id, name, number, email, method, address, total_products, total_price) VALUES(?,?,?,?,?,?,?,?)");
      $insert_order->execute([$user_id, $name, $number, $email, $method, $address, $total_products, $total_price]);

      $delete_cart = $conn->prepare("DELETE FROM `cart` WHERE user_id = ?");
      $delete_cart->execute([$user_id]);

      $message[] = 'order placed successfully!';
   }else{
      $message[] = 'your cart is empty';
   }

}

?>

<!-- HTML starts here -->
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Checkout</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">
   <style>
   /* #box:active{
     background-color: yellow;
   } */

   </style>

   <!-- javascript to submit the form -->
   <script>
   function show_alert() {

     var name = document.getElementById('name');
     var address1 = document.getElementById('address1');
     var address2 = document.getElementById('address2');
     var city = document.getElementById('city');
     var province = document.getElementById('province');
     var country = document.getElementById('country');
     var pin = document.getElementById('pin');
     // Name validation
     if(name.value === ''){
         alert('Name cannot be empty');
         return false;
     }

     // Making sure the value is in alphabets . Validation using Javascript
     var regName = /^[A-Za-z ]+$/;
     if(!regName.test(name.value)){
       alert('Invalid Name!');
       return false;
     }

     // ADDRESS 1 Validation -----------
     if(address1.value === ''){
         alert('House Number cannot be empty');
         return false;
     }

     var regAddress1 = /^[0-9]+$/;
     if(!regAddress1.test(address1.value)){
       alert('Invalid House Number!');
       return false;
     }



     // ADDRESS 2 validation
     if(address2.value === ''){
         alert('Street Name cannot be empty');
         return false;
     }


      var regExpStreet = /^[A-Za-z ]+$/;
      if(!regExpStreet.test(address2.value)){
        alert('Invalid Street Name');
        return false;
      }

      // CITY validation

      if(city.value === ''){
        alert('City value cannot be empty');
        return false;
      }

      var regExprCity = /^[A-Za-z ]+$/;
      if(!regExprCity.test(city.value)){
        alert('Invalid City!');
        return false;
      }

      // Province Validation
      if(province.value === ''){
        alert('Province value cannot be empty');
        return false;

      }

      var regExprProvince = /^[A-Za-z ]+$/;
      if(!regExprProvince.test(province.value)){
        alert('Invalid Province!');
        return false;
      }

      // Country Validation
      if(country.value === ''){
        alert('Country value cannot be empty');
        return false;
      }

      var regExprCountry = /^[A-Za-z ]+$/;
      if(!regExprCountry.test(country.value)){
        alert('Invalid Country!');
        return false;
      }

      // Pin validation
      if(pin.value === ''){
          alert('Pin cannot be empty');
          return false;
      }

      var regExprPin = /^[0-9]+$/;
      if(!regExprPin.test(pin.value)){
        alert('Invalid Pin!');
        return false;
      }


     alert("Do you want to place order? Is all information correct ? If yes click Ok");
   }

   </script>

</head>
<body>

<?php include 'components/user_header.php'; ?>

<section class="checkout-orders">

   <form action="" method="POST">

   <h3 style="background-color:blue">Your orders</h3>

      <div class="display-orders">
      <?php
         $grand_total = 0;
         $cart_items[] = '';
         $select_cart = $conn->prepare("SELECT * FROM `cart` WHERE user_id = ?");
         $select_cart->execute([$user_id]);
         if($select_cart->rowCount() > 0){
            while($fetch_cart = $select_cart->fetch(PDO::FETCH_ASSOC)){
               $cart_items[] = $fetch_cart['name'].' ('.$fetch_cart['price'].' x '. $fetch_cart['quantity'].') - ';
               $total_products = implode($cart_items);
               $grand_total += ($fetch_cart['price'] * $fetch_cart['quantity']);
      ?>
         <p> <?= $fetch_cart['name']; ?> <span>(<?= '$'.$fetch_cart['price'].'/- x '. $fetch_cart['quantity']; ?>)</span> </p>
      <?php
            }
         }else{
            echo '<p class="empty">your cart is empty!</p>';
         }
      ?>
         <input type="hidden" name="total_products" value="<?= $total_products; ?>">
         <input type="hidden" name="total_price" value="<?= $grand_total; ?>" value="">
         <div class="grand-total">grand total : <span>$<?= $grand_total; ?>/-</span></div>
      </div>

      <h3 style="background-color:blue">place your orders</h3>

      <div class="flex">
         <div class="inputBox">
            <span>Your name :</span>
            <input type="text" name="name" id="name" placeholder="Enter your name" class="box"  maxlength="20" required>
         </div>
         <div class="inputBox">
            <span>Your Phone number :</span>
            <input type="number" name="number" id="phonenumber" placeholder="Enter your number" class="box" min="0" max="9999999999" onkeypress="if(this.value.length == 10) return false;" required >
         </div>
         <div class="inputBox">
            <span>Your email :</span>
            <input type="email" name="email" id="email" placeholder="Enter your email" class="box" maxlength="50" required >
         </div>
         <div class="inputBox">
            <span>Payment method :</span>
            <select name="method" class="box" required>
               <option value="cash on delivery">Cash on delivery(COD)</option>
               <option value="credit card">Credit card</option>
               <option value="paytm">Gpay</option>
               <option value="paypal">Paypal</option>
            </select>
         </div>
         <div class="inputBox">
            <span>Address line 01 :</span>
            <input type="text" name="flat" id="address1" placeholder="House Number" class="box" maxlength="50" required>
         </div>
         <div class="inputBox">
            <span>Address line 02 :</span>
            <input type="text" name="street" id="address2" placeholder="Street Name" class="box" maxlength="50" required>
         </div>
         <div class="inputBox">
            <span>City :</span>
            <input type="text" name="city" id="city" placeholder="Enter your city" class="box" maxlength="50" required>
         </div>
         <div class="inputBox">
            <span>Province :</span>
            <input type="text" name="state" id="province" placeholder="Enter Province" class="box" maxlength="50" required>
         </div>
         <div class="inputBox">
            <span>Country :</span>
            <input type="text" name="country" id="country" placeholder="Enter Country" class="box" maxlength="50" required>
         </div>
         <div class="inputBox">
            <span>Pin :</span>
            <input type="number" min="0" id="pin" name="pin_code" placeholder="Enter Pin" min="0" max="999999" onkeypress="if(this.value.length == 6) return false;" class="box" required>
         </div>
      </div>

      <input type="submit" name="order" class="btn <?= ($grand_total > 1)?'':'disabled'; ?>" value="place order" onclick="show_alert();">

   </form>

</section>













<?php include 'components/footer.php'; ?>

<script src="js/script.js"></script>

</body>
</html>
