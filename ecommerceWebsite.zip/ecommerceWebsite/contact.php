<?php

// Connect to database
include 'components/connect.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
};

if(isset($_POST['send'])){

   $name = $_POST['name'];
   $name = filter_var($name, FILTER_SANITIZE_STRING);
   $email = $_POST['email'];
   $email = filter_var($email, FILTER_SANITIZE_STRING);
   $number = $_POST['number'];
   $number = filter_var($number, FILTER_SANITIZE_STRING);
   $msg = $_POST['msg'];
   $msg = filter_var($msg, FILTER_SANITIZE_STRING);

   $select_message = $conn->prepare("SELECT * FROM `messages` WHERE name = ? AND email = ? AND number = ? AND message = ?");
   $select_message->execute([$name, $email, $number, $msg]);

   if($select_message->rowCount() > 0){
      $message[] = 'already sent message!';
   }else{

      $insert_message = $conn->prepare("INSERT INTO `messages`(user_id, name, email, number, message) VALUES(?,?,?,?,?)");
      $insert_message->execute([$user_id, $name, $email, $number, $msg]);

      $message[] = 'sent message successfully!';

   }

}


?>

<!-- HTML starts here -->
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>contact</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">
   <script>
   function show_alert(){
     var name = document.getElementById('name');
     var email = document.getElementById('email');
     var number = document.getElementById('number');
     var message = document.getElementById('message');

     // Validation for name
     if(name.value === ''){
       alert('Name Required!');
       return false;
     }

     var regName = /^[A-Za-z ]+$/;
     if(!regName.test(name.value)){
       alert('Invalid Name!');
       return false;
     }

     // Validation for number
     if(number.value === ''){
       alert('Number Required');
       return false;
     }

     var regExprNumber = /^[0-9]+$/;
     if(!regExprNumber.test(number.value)){
       alert('Invalid Number!');
       return false;
     }

     // Validation for messages
     if(message.value === ''){
       alert('Write your Message!');
       return false;
     }


   }
   </script>
   <style>
   #name:focus {
     background-color: lightblue;
   }

   #email:focus {
     background-color: lightblue;
   }

   #number:focus {
     background-color: lightblue;
   }

   #message:focus {
     background-color: lightblue;
   }

   </style>
</head>
<body>

<?php include 'components/user_header.php'; ?>

<section class="contact">

   <form action="" method="post" style="background-image: url('images/back1.jpg');background-repeat: no-repeat;background-size:100%;">
      <h3 style="background-color:tomato;color:white;">Contact Us</h3>
      <input type="text" name="name" id="name" placeholder="Enter your name" required maxlength="20" class="box">
      <input type="email" name="email" id="email" placeholder="Enter your email" required maxlength="50" class="box">
      <input type="number" name="number" id="number" min="0" max="9999999999" placeholder="Enter your number" required onkeypress="if(this.value.length == 10) return false;" class="box">
      <textarea name="msg" class="box" id="message" placeholder="Enter your message" cols="30" rows="10"></textarea>
      <input type="submit" value="send message" name="send" class="btn" onclick="show_alert();">
   </form>

</section>













<?php include 'components/footer.php'; ?>

<script src="js/script.js"></script>

</body>
</html>
