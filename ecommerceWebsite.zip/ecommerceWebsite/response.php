<?php

$conn = mysqli_connect("localhost","root","","shop_db");

$result = mysqli_query($conn,"SELECT price from products");

$data = array();

while($row = mysqli_fetch_assoc($result)){
  $data[] = $row;
}

echo json_encode($data);
?>
